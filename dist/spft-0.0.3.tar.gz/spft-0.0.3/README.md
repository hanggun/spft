# spft
standard python functional tools
